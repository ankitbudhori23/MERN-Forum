import Header from "./Header";
import Question from "./Question";

export default function App() {
  return (
    <>
      <Header />
      <Question />
    </>
  );
}
