export default function Header() {
  return (
    <>
      <nav class="navbar navbar-light bg-light ">
        <div class="container-fluid justify-content-center">
          <a class="navbar-brand" href="#">
            Question
          </a>
          <a class="navbar-brand" href="#">
            Trending Question
          </a>
        </div>
      </nav>
    </>
  );
}
